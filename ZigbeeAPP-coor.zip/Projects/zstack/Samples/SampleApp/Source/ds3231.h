#ifndef DS3231_H
#define DS3231_H

#include "my_i2c.h"

typedef struct DateTimeStruct{
	uint8 second;
	uint8 minute;
	uint8 hour;
	uint8 dayofmonth;
	uint8 month;
	uint16 year;
	uint8 dayOfWeek;  /*Su=0 Mo=1 Tu=3 We=4 Th=5 Fr=6 Sa=7 */
}DateTime_t;

extern DateTime_t my_time;
extern DateTime_t set_time;

#define DS3231_ADDRESS	        0x68             //I2C Slave address
#define	DS3231_WRITE_ADDR	    ((0x68<<1) | 0)  // DS3231 ��д��ַ
#define	DS3231_READ_ADDR		((0x68<<1) | 1)  // DS3231 �Ķ���ַ

/* DS3231 Registers. Refer Sec 8.2 of application manual */
#define DS3231_SEC_REG        0x00
#define DS3231_MIN_REG        0x01
#define DS3231_HOUR_REG       0x02
#define DS3231_WDAY_REG       0x03
#define DS3231_MDAY_REG       0x04
#define DS3231_MONTH_REG      0x05
#define DS3231_YEAR_REG       0x06

#define DS3231_AL1SEC_REG     0x07
#define DS3231_AL1MIN_REG     0x08
#define DS3231_AL1HOUR_REG    0x09
#define DS3231_AL1WDAY_REG    0x0A

#define DS3231_AL2MIN_REG     0x0B
#define DS3231_AL2HOUR_REG    0x0C
#define DS3231_AL2WDAY_REG    0x0D

#define DS3231_CONTROL_REG          0x0E
#define DS3231_STATUS_REG           0x0F
#define DS3231_AGING_OFFSET_REG     0x0F
#define DS3231_TMP_UP_REG           0x11
#define DS3231_TMP_LOW_REG          0x12

#define EverySecond     0x01
#define EveryMinute     0x02
#define EveryHour       0x03


extern void my_ds3231_set_date(DateTime_t t);
extern void my_ds3231_set_time(DateTime_t t);
extern void my_ds3231_get_date(DateTime_t* ans);
extern void my_ds3231_get_time(DateTime_t* ans);

extern uint8 bcdToDec(uint8 byte);
extern void my_ds3231_init(void);



#endif