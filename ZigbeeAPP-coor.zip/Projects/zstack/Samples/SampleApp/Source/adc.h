#ifndef ADC_H
#define ADC_H

#include "main.h"

#define MY_VDD  3.300f              // ��Դ��ѹ

// battery
#define MY_BAT_FULL         4.2f    // ��������ѹ
#define MY_BAT_EMPTY        3.7f    // ��ؿյ��ѹ
#define MIN_BATTERY_VOLTAGE 3.5f    // ���δ���ӵ�ѹ�����ֵ
#define LOW_BATTERY_VOLTAGE 3.9f    // ��ص͵�����ѹ�����ֵ



// light
#define MY_LIGHT_MAX        5000

#define ADC_MULTI           2

extern uint16 my_battery_voltage_d;
extern float  my_battery_voltage_f;
extern uint8  my_battery_voltage_p;
extern uint16 my_mq2_voltage_d;
extern uint16 my_mq2;
extern uint16 my_light_voltage_d;
extern uint16 my_light;


extern void my_adc_init(void);
extern void my_get_battery_voltage(uint8 resolution);
extern void my_get_mq2(uint8 resolution);
extern void my_get_light(uint8 resolution);


#endif // adc.h