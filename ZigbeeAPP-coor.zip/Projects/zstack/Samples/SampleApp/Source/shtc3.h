#ifndef SHTC3_H
#define SHTC3_H

#include "my_i2c.h"


extern uint32 SHTC3_Data;
extern float SHTC3_TMP;
extern float SHTC3_HUM;

#define SHTC3_READ_ADDR  ((0x44<<1) | 1)  //SHTC3�Ķ���ַ
#define SHTC3_WRITE_ADDR ((0x44<<1) | 0)  //SHTC3��д��ַ

extern uint32 my_shtc3_read(void);
extern void my_shtc3_test(void);




#endif // shtc3.h