#ifndef UART0_H
#define UART0_H
#ifdef __cplusplus
extern "C"
{
#endif
#include "main.h"
#include <string.h>
 
#define UART0_RX_BUFF_MAX    60
#define UART0_TX_BUFF_MAX    60
#define UART0_THRESHOLD      (UART0_RX_BUFF_MAX / 2)
#define UART0_IDLE_TIMEOUT   6
 
extern uint8 UART0_RX_BUFF[UART0_RX_BUFF_MAX];//���ջ����� 
extern uint8 UART0_RX_STA;                    //����״̬���	
extern uint8 UART0_RX_LEN;                    //�������ݳ���
 
extern void my_uart0_hal_init(uint8 baudRate);
extern void my_uart0_data_process(void);
extern void my_uart0_hal_data_receive( uint8 port, uint8 event );
extern void my_uart0_hal_reset( void );

extern void my_uart0_send(const uint8 *data, uint8 len);

extern void my_uart0_cmd(uint8 *rxdata);
 
#ifdef __cplusplus
}
#endif
#endif /* UART0_H */