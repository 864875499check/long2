#ifndef MY_LOG_H
#define MY_LOG_H

#include "main.h"

#include "pwr.h"
#include "sgp30.h"
#include "shtc3.h"
#include "ds3231.h"
#include "adc.h"
#include "mq2.h"
#include "oled.h"

extern void my_log_time(void);
extern void my_log_pwr(void);
extern void my_log_mq2(void);
extern void my_log_light(void);
extern void my_log_shtc3(void);
extern void my_log_sgp30(void);
extern void my_log_all(void);

#endif  // my_log.h