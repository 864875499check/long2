/*********************************************************************
 * INCLUDES
 */
#include "OSAL.h"
#include "ZGlobals.h"
#include "AF.h"
#include "aps_groups.h"
#include "ZDApp.h"

#include "SampleAppHw.h"

#include "OnBoard.h"

// my includes
#include "SampleApp_TAO.h"
#include "main.h"
#include "key.h"
#include "uart.h"
#include "uart0.h"

/* HAL */
#include "hal_lcd.h"
#include "hal_led.h"
#include "hal_key.h"

/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * CONSTANTS
 */

/*********************************************************************
 * TYPEDEFS
 */

/*********************************************************************
 * GLOBAL VARIABLES
 */

// This list should be filled with Application specific Cluster IDs.
const cId_t SampleApp_ClusterList[SAMPLEAPP_MAX_CLUSTERS] =
{
    SAMPLEAPP_POINT_TO_POINT_CLUSTERID,
    SAMPLEAPP_BROADCAST_CLUSTERID,
};

const SimpleDescriptionFormat_t SampleApp_SimpleDesc =
{
  SAMPLEAPP_ENDPOINT,              //  int Endpoint;
  SAMPLEAPP_PROFID,                //  uint16 AppProfId[2];
  SAMPLEAPP_DEVICEID,              //  uint16 AppDeviceId[2];
  SAMPLEAPP_DEVICE_VERSION,        //  int   AppDevVer:4;
  SAMPLEAPP_FLAGS,                 //  int   AppFlags:4;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList,  //  uint8 *pAppInClusterList;
  SAMPLEAPP_MAX_CLUSTERS,          //  uint8  AppNumInClusters;
  (cId_t *)SampleApp_ClusterList   //  uint8 *pAppInClusterList;
};

// This is the Endpoint/Interface description.  It is defined here, but
// filled-in in SampleApp_Init().  Another way to go would be to fill
// in the structure here and make it a "const" (in code space).  The
// way it's defined in this sample app it is define in RAM.
endPointDesc_t SampleApp_epDesc;

/*********************************************************************
 * EXTERNAL VARIABLES
 */

/*********************************************************************
 * EXTERNAL FUNCTIONS
 */

/*********************************************************************
 * LOCAL VARIABLES
 */
uint8 SampleApp_TaskID;   // Task ID for internal task/event processing
                          // This variable will be received when
                          // SampleApp_Init() is called.
devStates_t SampleApp_NwkState;

uint8 SampleApp_TransID;  // This is the unique message ID (counter)

afAddrType_t SampleApp_Point2Point_DstAddr; // �㲥��ַ

aps_Group_t SampleApp_Group;

uint8 SampleAppPeriodicCounter = 0;
uint8 SampleAppFlashCounter = 0;

/*********************************************************************
 * LOCAL FUNCTIONS
 */
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pckt );
void My_SampleApp_SendPointToPointMessage( void );
void SampleApp_HandleKeys( uint8 shift, uint8 keys );

/*********************************************************************
 * NETWORK LAYER CALLBACKS
 */

/*********************************************************************
 * PUBLIC FUNCTIONS
 */

static void rxCB(uint8 port,uint8 event)
{
	uint8  ch;  
	uint8  rxBuffer[128];  
	uint8 len = 0;  
	while (Hal_UART_RxBufLen(port))  
	{      
		HalUARTRead (port, &ch, 1);
		rxBuffer[len]  = ch;      
		len++;  
	}  
	if(len)  
	{      
		HalUARTWrite(0,rxBuffer,len); 
		len = 0;
	}
}

/*********************************************************************
 * @fn      SampleApp_Init
 *
 * @brief   Initialization function for the Generic App Task.
 *          This is called during initialization and should contain
 *          any application specific initialization (ie. hardware
 *          initialization/setup, table initialization, power up
 *          notificaiton ... ).
 *
 * @param   task_id - the ID assigned by OSAL.  This ID should be
 *                    used to send messages and set timers.
 *
 * @return  none
 */
void SampleApp_Init( uint8 task_id )
{
  halUARTCfg_t  uartConfig;
  
  SampleApp_TaskID = task_id;
  SampleApp_NwkState = DEV_INIT;
  SampleApp_TransID = 0;

  // Device hardware initialization can be added here or in main() (Zmain.c).
  // If the hardware is application specific - add it here.
  // If the hardware is other parts of the device add it in main().

 #if defined ( BUILD_ALL_DEVICES )
  // The "Demo" target is setup to have BUILD_ALL_DEVICES and HOLD_AUTO_START
  // We are looking at a jumper (defined in SampleAppHw.c) to be jumpered
  // together - if they are - we will start up a coordinator. Otherwise,
  // the device will start as a router.
  if ( readCoordinatorJumper() )
    zgDeviceLogicalType = ZG_DEVICETYPE_COORDINATOR;
  else
    zgDeviceLogicalType = ZG_DEVICETYPE_ROUTER;
#endif // BUILD_ALL_DEVICES

#if defined ( HOLD_AUTO_START )
  // HOLD_AUTO_START is a compile option that will surpress ZDApp
  //  from starting the device and wait for the application to
  //  start the device.
  ZDOInitDevice(0);
#endif

  // Setup for the periodic message's destination address
 
  // my_�ն��豸��Ե㵽Э����
  SampleApp_Point2Point_DstAddr.addrMode = (afAddrMode_t)Addr16Bit;    //�̵�ַ��ʽ
  SampleApp_Point2Point_DstAddr.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_Point2Point_DstAddr.addr.shortAddr = 0x0000;   //�̵�ַ�����ݷ��͵�Э����

  // Setup for the flash command's destination address - Group 1
  //...

  // Fill out the endpoint description.
  SampleApp_epDesc.endPoint = SAMPLEAPP_ENDPOINT;
  SampleApp_epDesc.task_id = &SampleApp_TaskID;
  SampleApp_epDesc.simpleDesc
            = (SimpleDescriptionFormat_t *)&SampleApp_SimpleDesc;
  SampleApp_epDesc.latencyReq = noLatencyReqs;

  // Register the endpoint description with the AF
  afRegister( &SampleApp_epDesc );

  // Register for all key events - This app will handle all key events
  RegisterForKeys( SampleApp_TaskID );

  // By default, all devices start out in Group 1
  //...

#if defined ( LCD_SUPPORTED )
  HalLcdWriteString( "SampleApp", HAL_LCD_LINE_1 );
#endif
  
  // my init
  /* ��ֲ��HAL��LED, UART0, �Զ����KEY */
  my_uart0_hal_init(HAL_UART_BR_115200);    // ��ֲHAL��
  //my_led_init();      // �Զ���LED
  my_key_init();        // �Զ���KEY
  //my_uart0_init();    // �Զ���UART0---������,���޸�IDE����,���ٴγ���
}

/*********************************************************************
 * @fn      SampleApp_ProcessEvent
 *
 * @brief   Generic Application Task event processor.  This function
 *          is called to process all events for the task.  Events
 *          include timers, messages and any other user defined events.
 *
 * @param   task_id  - The OSAL assigned task ID.
 * @param   events - events to process.  This is a bit map and can
 *                   contain more than one event.
 *
 * @return  none
 */
uint16 SampleApp_ProcessEvent( uint8 task_id, uint16 events )
{
  afIncomingMSGPacket_t *MSGpkt;
  (void)task_id;  // Intentionally unreferenced parameter

  if ( events & SYS_EVENT_MSG )
  {
    MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    while ( MSGpkt )
    {
      switch ( MSGpkt->hdr.event )
      {
        // Received when a key is pressed
        case KEY_CHANGE:
          break;

        // Received when a messages is received (OTA) for this endpoint
        case AF_INCOMING_MSG_CMD:
          SampleApp_MessageMSGCB( MSGpkt );
          break;

        // Received whenever the device changes state in the network
        case ZDO_STATE_CHANGE:
          SampleApp_NwkState = (devStates_t)(MSGpkt->hdr.status);
          if ( (SampleApp_NwkState == DEV_ZB_COORD)
              || (SampleApp_NwkState == DEV_ROUTER)
              || (SampleApp_NwkState == DEV_END_DEVICE) )
          {
            // Start sending the periodic message in a regular interval.
            // my_��һ���ϵ�����ʱ��ִ�еĴ���
            osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_MY_MONITOR_EVT, 0 );    // �����������м���¼�
            HalLedBlink(HAL_LED_1, 10, 10, 200); // ����״̬�仯ledָʾ(��˸10��,����10%,��˸����200ms)
            
            /* ��ʼ���ҵ��豸���� */
            MY_DEVICE_TYPE = MY_END_DEVICE_TYPE;
          }
          else
          {
            // Device is no longer in the network
          }
          break;

        default:
          break;
      }

      // Release the memory
      osal_msg_deallocate( (uint8 *)MSGpkt );

      // Next - if one is available
      MSGpkt = (afIncomingMSGPacket_t *)osal_msg_receive( SampleApp_TaskID );
    }

    // return unprocessed events
    return (events ^ SYS_EVENT_MSG);
  }
  
  // my_key_event
  if ( events & SAMPLEAPP_MY_KEY_EVT )
  {
      if(KEY_interval_time < 500)      // ����ʱ��С��1s
      {
          my_key_process_1();
      }
      else if(KEY_interval_time < 5000) // ����ʱ��1~5s
      {
          my_key_process_2();
      }
      else                              // ����ʱ�����5s
      {
          my_key_process_3();
      }
      
      // return unprocessed events
      return (events ^ SAMPLEAPP_MY_KEY_EVT);
  }
  
  // my_monitor_event
  if ( events & SAMPLEAPP_MY_MONITOR_EVT )
  {
      // user code begin
      // ...
      // end
      
      osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_MY_MONITOR_EVT, 1000 );
      // return unprocessed events
      return (events ^ SAMPLEAPP_MY_MONITOR_EVT);
  }
  
  // my_send_uart0_data_event
  if ( events & SAMPLEAPP_SEND_UART0_MSG_EVT )
  {
      // user code begin
      printf(UART0_RX_BUFF);    // �������ݻ���
      AF_DataRequest( &SampleApp_Point2Point_DstAddr, &SampleApp_epDesc,
                      SAMPLEAPP_POINT_TO_POINT_CLUSTERID,
                      UART0_RX_LEN,
                      UART0_RX_BUFF,
                      &SampleApp_TransID,
                      AF_DISCV_ROUTE,
                      AF_DEFAULT_RADIUS );
      // end
      
      my_uart0_hal_reset();                 // �������buffer
      HalLedBlink(HAL_LED_1, 2, 10, 200);   // �������ָʾ
      // return unprocessed events
      return (events ^ SAMPLEAPP_SEND_UART0_MSG_EVT);
  }

  // Send a message out - This event is generated by a timer
  //  (setup in SampleApp_Init()).
  if ( events & SAMPLEAPP_SEND_PERIODIC_MSG_EVT )
  {
    // user code begin
    // ...
    // end

    // Setup to send message again in normal period (+ a little jitter)
    // my_�¼�ִ�н����ٴδ��������¼�
    osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_PERIODIC_MSG_EVT,
        (SAMPLEAPP_SEND_PERIODIC_MSG_TIMEOUT + (osal_rand() & 0x00FF)) );

    // return unprocessed events
    return (events ^ SAMPLEAPP_SEND_PERIODIC_MSG_EVT);
  }

  // Discard unknown events
  return 0;
}

/*********************************************************************
 * LOCAL FUNCTIONS
 */

/*********************************************************************
 * @fn      SampleApp_MessageMSGCB
 *
 * @brief   Data message processor callback.  This function processes
 *          any incoming data - probably from other devices.  So, based
 *          on cluster ID, perform the intended action.
 *
 * @param   none
 *
 * @return  none
 */
void SampleApp_MessageMSGCB( afIncomingMSGPacket_t *pkt )
{
  uint8  i;

  switch ( pkt->clusterId )
  {
    case SAMPLEAPP_BROADCAST_CLUSTERID:     // �㲥���ݴ�
      // user code begin
        osal_memcpy(MY_AF_BUFF, pkt->cmd.Data, pkt->cmd.DataLength);
        printf(MY_AF_BUFF); // �����������ݻ���
        
      // end
      memset(MY_AF_BUFF, 0, MY_AF_RX_BUFF_MAX); // �������buffer
      HalLedBlink(HAL_LED_1, 2, 10, 200);       // �������ָʾ
      break;
  }
}

/*********************************************************************
 * @fn      My_SampleApp_SendPointToPointMessage
 *
 * @brief   Send the point2point message.
 *
 * @param   none
 *
 * @return  none
 */
void My_SampleApp_SendPointToPointMessage( void )
{
  if ( AF_DataRequest( &SampleApp_Point2Point_DstAddr, &SampleApp_epDesc,
                       SAMPLEAPP_POINT_TO_POINT_CLUSTERID,
                       1,
                       (uint8*)&SampleAppPeriodicCounter,
                       &SampleApp_TransID,
                       AF_DISCV_ROUTE,
                       AF_DEFAULT_RADIUS ) == afStatus_SUCCESS )
  {
  }
  else
  {
    // Error occurred in request to send.
  }
}

/*********************************************************************
 * Event Generation Functions
 */
/*********************************************************************
 * @fn      SampleApp_HandleKeys
 *
 * @brief   Handles all key events for this device.
 *
 * @param   shift - true if in shift/alt.
 * @param   keys - bit field for key events. Valid entries:
 *                 HAL_KEY_SW_2
 *                 HAL_KEY_SW_1
 *
 * @return  none
 */
void SampleApp_HandleKeys( uint8 shift, uint8 keys )
{
  (void)shift;  // Intentionally unreferenced parameter

  if ( keys & HAL_KEY_SW_2 )
  {
      // my_user code:
      
  }
}


/*********************************************************************
*********************************************************************/
