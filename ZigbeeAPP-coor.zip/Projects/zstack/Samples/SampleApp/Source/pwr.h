#ifndef PWR_H
#define PWR_H

#include "main.h"

extern uint32 my_pwr_sleep_times;

#define MY_PWR_WAKEUP_TIMEOUT   2

#define MY_PWR_MODE_0       0x00
#define MY_PWR_MODE_1       0x01
#define MY_PWR_MODE_2       0x02
#define MY_PWR_MODE_3       0x03
#define MY_PWR_MODE_WAKEUP  0x04
#define MY_PWR_MODE_TIMER   MY_PWR_MODE_2   //��ʱ����
#define MY_PWR_MODE_DEEP    MY_PWR_MODE_3   //�������
#define XOSC_FREQUENCY  32753   // 32 kHz XOSC ����Ƶ��


static void my_set_PM2_sleeptimer(uint32 sec);
extern void my_set_pwr_mode(uint8 mode, uint32 sec);
__interrupt void ST_ISR(void);


#define IIC_PWR_OFF 0
#define IIC_PWR_ON  1
// port
#define MY_IIC_DEV_PWR      P1_3

extern uint8 iic_device_pwr;
extern void my_iic_device_pwr(uint8 mode);


#endif  // pwr.h