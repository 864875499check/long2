#include "my_log.h"

void my_log_time(void)
{
    my_ds3231_get_date(&my_time);
    my_ds3231_get_time(&my_time);
    printf("[%d-%d-%d, %d:%d:%d]\r\n", my_time.year, my_time.month, my_time.dayofmonth, my_time.hour, my_time.minute, my_time.second);
}
void my_log_pwr(void)
{
    my_get_battery_voltage(HAL_ADC_RESOLUTION_14);
    printf("Power:\t%d%%\r\n"/*, my_battery_voltage_f*/, my_battery_voltage_p);
}
void my_log_mq2(void)
{
    my_get_mq2(HAL_ADC_RESOLUTION_14);
    printf("MQ2:\t%d\r\n", my_mq2);
}
void my_log_light(void)
{
    my_get_light(HAL_ADC_RESOLUTION_14);
    printf("Light:\t%d\r\n", my_light);
}
void my_log_shtc3(void)
{
    my_shtc3_test();
    printf("Temperature:\t%2.2fC\r\nHumidity:\t%2.2f%%\r\n", SHTC3_TMP, SHTC3_HUM);
}
void my_log_sgp30(void)
{
    my_sgp30_test();
    printf("CO2:\t%dppm\r\nTVOC:\t%dppd\r\n", SGP30_CO2, SGP30_TVOC);
}
void my_log_all(void)
{
    my_log_time();
    my_log_pwr();
    my_log_mq2();
    my_log_light();
    my_log_shtc3();
    my_log_sgp30();
}