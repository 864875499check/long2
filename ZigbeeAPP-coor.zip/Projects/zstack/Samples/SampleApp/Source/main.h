#ifndef MAIN_H
#define MAIN_H

#define IS_END_DEV 0

// sys
#include "hal_types.h"
#include "OSAL_Timers.h"
#include <ioCC2530.h>
#include <stdio.h>
// HAL
#include "hal_led.h"
#include "hal_key.h"
#include "hal_adc.h"
// my
#include "SampleApp_TAO.h"

// ȫ�ֱ���
extern uint32 my_global_runtime;
extern uint8  my_sleep_status;

// ����ID
extern uint8 SampleApp_TaskID;

#define SLEEP   TRUE

// �豸����
#define MY_COORDINATOR_TYPE     1
#define MY_ROUTER_TYPE          2
#define MY_END_DEVICE_TYPE      3
extern uint8 MY_DEVICE_TYPE;

// �豸����
#define DEV_NAME    "DEV_End_Device-No.2"

// ��������
#define MY_AF_RX_BUFF_MAX_LEN    60
#define MY_AF_TX_BUFF_MAX_LEN    60
extern uint8 MY_AF_BUFF[MY_AF_RX_BUFF_MAX_LEN];

// ����ʱ��
#define MY_INDICATE_DURATION   150

#define BIT(n)  (1<<(n))

// io�˿�����/���ģʽ���ú�
#define SET_PORT_X_DIR(port, pin, mode) \
do{                                       \
  if(mode)                              \
    P##port##DIR |= BIT(pin);           \
  else                                  \
    P##port##DIR &= ~BIT(pin);          \
}while(0)


// debug info
#define Print_ERROR() printf("my_sys_runtime_at:%ds\r\n",my_global_runtime)


#define IO_0            0
#define IO_1            1
#define IO_2            2
#define IO_3            3
#define IO_4            4
#define IO_5            5
#define IO_6            6
#define IO_7            7
#define IO_INPUT_MODE   0
#define IO_OUTPUT_MODE  1
extern void my_set_p0_mode(int io, uint8 mode);
extern void my_set_p1_mode(int io, uint8 mode);
extern void my_set_p2_mode(int io, uint8 mode);

#if IS_END_DEV
extern void my_init_all(void);
#endif

#endif  // main.h