#ifndef OLED_H
#define OLED_H

#include "main.h"
#include "my_i2c.h"


#define OLED_WRITE_ADDR 0x78
#define OLED_CMD    0	// д����
#define OLED_DATA   1	// д����
#define OLED_ON     1
#define OLED_OFF    0
#define OLED_DATA_REG   0x40    // д����-�Ĵ���
#define OLED_CMD_REG    0x00    // д����-�Ĵ���

#define OLED_FONT_0806  8
#define OLED_FONT_1206  12
#define OLED_FONT_1608  16
#define OLED_FONT_2412  24
#define OLED_DIS_REVERSE 0  // ��ɫ��ʾ
#define OLED_DIS_NORMAL  1

// oled�߽�
#define OLED_OFFSET_TOP     17  // ��
#define OLED_OFFSET_BOT     62  // ��
#define OLED_OFFSET_L       1   // ��
#define OLED_OFFSET_R       126 // ��




extern void my_oled_color_turn(uint8 mode);
extern void my_oled_display_turn(uint8 mode);

extern void my_oled_draw_point(uint8 x, uint8 y, uint8 t);
extern void my_oled_char(uint8 x, uint8 y, uint8 chr, uint8 size1, uint8 mode);
extern void my_oled_string(uint8 x, uint8 y, uint8 *chr, uint8 size1, uint8 mode);
extern void my_oled_num(uint8 x, uint8 y, uint8 num, uint8 len, uint8 size1, uint8 mode);
extern void my_oled_line(uint8 x1, uint8 y1, uint8 x2, uint8 y2, uint8 mode);

extern void my_oled_sensor_data(void);

extern void my_oled_refresh(void);
extern void my_oled_clear(void);
extern void my_oled_init(void);
extern void my_oled_display_on(uint8 mode);

#endif  // oled.h
