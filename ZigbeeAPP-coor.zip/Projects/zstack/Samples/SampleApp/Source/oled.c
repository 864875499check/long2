#include "oled.h"
#include "oledfont.h"

uint8 OLED_GRAM[144][8];    // oled�Դ�

static void my_oled_write_byte(uint8 data, uint8 mode)
{
    my_iic_start();
    my_iic_write_byte(OLED_WRITE_ADDR);
    my_iic_wait_ack();
    
    if(mode == OLED_DATA)
        my_iic_write_byte(OLED_DATA_REG);
    else
        my_iic_write_byte(OLED_CMD_REG);
    my_iic_wait_ack();
    
    my_iic_write_byte(data);
    my_iic_wait_ack();
    my_iic_stop();
}

//���Ժ���
void my_oled_color_turn(uint8 mode)
{
    if(mode == 0)
        my_oled_write_byte(0xA6, OLED_CMD); //������ʾ
    else
        my_oled_write_byte(0xA7, OLED_CMD); //��ɫ��ʾ
}

//��Ļ��ת180��
void my_oled_display_turn(uint8 mode)
{
    if(mode == 0)
    {
        my_oled_write_byte(0xC8,OLED_CMD); //������ʾ
        my_oled_write_byte(0xA1,OLED_CMD);
    }
    else
    {
        my_oled_write_byte(0xC0,OLED_CMD); //��ת��ʾ
        my_oled_write_byte(0xA0,OLED_CMD);
    }
}

//���� 
//x:0~127
//y:0~63
//t:1 ��� 0,���
void my_oled_draw_point(uint8 x, uint8 y, uint8 t)
{
	uint8 i,m,n;
	i=y/8;
	m=y%8;
	n=1<<m;
	if(t){OLED_GRAM[x][i]|=n;}
	else
	{
		OLED_GRAM[x][i]=~OLED_GRAM[x][i];
		OLED_GRAM[x][i]|=n;
		OLED_GRAM[x][i]=~OLED_GRAM[x][i];
	}
}

//��ʾ�ַ�
//��ָ��λ����ʾһ���ַ�,���������ַ�
//x:0~127
//y:0~63
//size1:ѡ������ 6x8/6x12/8x16/12x24
//mode:0,��ɫ��ʾ;1,������ʾ
void my_oled_char(uint8 x, uint8 y, uint8 chr, uint8 size1, uint8 mode)
{
	uint8 i,m,temp,size2,chr1;
	uint8 x0=x,y0=y;
	if(size1==8)size2=6;
	else size2=(size1/8+((size1%8)?1:0))*(size1/2);  //�õ�����һ���ַ���Ӧ������ռ���ֽ���
	chr1=chr-' ';  //����ƫ�ƺ��ֵ
	for(i=0;i<size2;i++)
	{
		if(size1==8)
        {temp=asc2_0806[chr1][i];} //����0806����
        /*
		else if(size1==12)
        {temp=asc2_1206[chr1][i];} //����1206����
		else if(size1==16)
        {temp=asc2_1608[chr1][i];} //����1608����
		else if(size1==24)
        {temp=asc2_2412[chr1][i];} //����2412����
        */
		else return;
		for(m=0;m<8;m++)
		{
			if(temp&0x01)my_oled_draw_point(x,y,mode);
			else my_oled_draw_point(x,y,!mode);
			temp>>=1;
			y++;
		}
		x++;
		if((size1!=8)&&((x-x0)==size1/2))
		{x=x0;y0=y0+8;}
		y=y0;
  }
}

//��ʾ�ַ���
//x,y:�������  
//size1:�����С 
//*chr:�ַ�����ʼ��ַ 
//mode:0,��ɫ��ʾ;1,������ʾ
void my_oled_string(uint8 x, uint8 y, uint8 *chr, uint8 size1, uint8 mode)
{
	while((*chr>=' ')&&(*chr<='~'))//�ж��ǲ��ǷǷ��ַ�!
	{
		my_oled_char(x,y,*chr,size1,mode);
		if(size1==8)x+=6;
		else x+=size1/2;
		chr++;
    }
}

static uint32 my_pow(uint8 m, uint8 n)
{
	uint32 result=1;
	while(n--)
	{
	  result*=m;
	}
	return result;
}

//��ʾ����
//x,y :�������
//num :Ҫ��ʾ������
//len :���ֵ�λ��
//size:�����С
//mode:0,��ɫ��ʾ;1,������ʾ
void my_oled_num(uint8 x, uint8 y, uint8 num, uint8 len, uint8 size1, uint8 mode)
{
	uint8 t,temp,m=0;
	if(size1==8)m=2;
	for(t=0;t<len;t++)
	{
		temp=(num/my_pow(10,len-t-1))%10;
        if(temp==0)
            my_oled_char(x+(size1/2+m)*t,y,'0',size1,mode);
        else 
            my_oled_char(x+(size1/2+m)*t,y,temp+'0',size1,mode);
    }
}

//����
//x1,y1:�������
//x2,y2:��������
void my_oled_line(uint8 x1, uint8 y1, uint8 x2, uint8 y2, uint8 mode)
{
	uint16 t; 
	int xerr=0,yerr=0,delta_x,delta_y,distance;
	int incx,incy,uRow,uCol;
	delta_x=x2-x1;                          //������������ 
	delta_y=y2-y1;
	uRow=x1;                                //�����������
	uCol=y1;
	if(delta_x>0)incx=1;                    //���õ������� 
	else if (delta_x==0)incx=0;             //��ֱ�� 
	else {incx=-1;delta_x=-delta_x;}
	if(delta_y>0)incy=1;
	else if (delta_y==0)incy=0;             //ˮƽ�� 
	else {incy=-1;delta_y=-delta_x;}
	if(delta_x>delta_y)distance=delta_x;    //ѡȡ�������������� 
	else distance=delta_y;
	for(t=0;t<distance+1;t++)
	{
		my_oled_draw_point(uRow,uCol,mode); //����
		xerr+=delta_x;
		yerr+=delta_y;
		if(xerr>distance)
		{
			xerr-=distance;
			uRow+=incx;
		}
		if(yerr>distance)
		{
			yerr-=distance;
			uCol+=incy;
		}
	}
}

#include "adc.h"
#include "ds3231.h"
#include "shtc3.h"
#include "sgp30.h"
void my_oled_sensor_data(void)
{
    // date-time
    my_oled_string(1, OLED_OFFSET_TOP+1, "[20  -  -  ,  :  :  ]", OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+18, OLED_OFFSET_TOP+1, my_time.year-2000, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+36, OLED_OFFSET_TOP+1, my_time.month, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+54, OLED_OFFSET_TOP+1, my_time.dayofmonth, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+72, OLED_OFFSET_TOP+1, my_time.hour, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+90, OLED_OFFSET_TOP+1, my_time.minute, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(1+108, OLED_OFFSET_TOP+1, my_time.second, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    // humi & temp  
    my_oled_string(2, OLED_OFFSET_TOP+1+10, "Temp:  C   Humi:  %", OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+30, OLED_OFFSET_TOP+1+10, SHTC3_TMP, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+96, OLED_OFFSET_TOP+1+10, SHTC3_HUM, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    // light & mq2
    my_oled_string(2, OLED_OFFSET_TOP+1+20, "Light:     MQ2:    ", OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+36, OLED_OFFSET_TOP+1+20, my_light/100, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+48, OLED_OFFSET_TOP+1+20, my_light%100, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+90, OLED_OFFSET_TOP+1+20, my_mq2/100, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+102, OLED_OFFSET_TOP+1+20, my_mq2%100, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    // CO2 & power
    if(my_battery_voltage_p == 100)
        my_oled_string(2, OLED_OFFSET_TOP+1+30, "CO2:   ppm PWR:MAX", OLED_FONT_0806, OLED_DIS_NORMAL);
    else
    {
        my_oled_string(2, OLED_OFFSET_TOP+1+30, "CO2:   ppm PWR:  %", OLED_FONT_0806, OLED_DIS_NORMAL);
        my_oled_num(2+90, OLED_OFFSET_TOP+1+30, my_battery_voltage_p, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    }
    my_oled_num(2+24, OLED_OFFSET_TOP+1+30, SGP30_CO2/100, 1, OLED_FONT_0806, OLED_DIS_NORMAL);
    my_oled_num(2+30, OLED_OFFSET_TOP+1+30, SGP30_CO2%100, 2, OLED_FONT_0806, OLED_DIS_NORMAL);
    
    my_oled_refresh();
}

void my_oled_refresh(void)
{
    uint8 i,n;
    for(i=0;i<8;i++)
    {
        my_oled_write_byte(0xb0+i,  OLED_CMD);  //��������ʼ��ַ
		my_oled_write_byte(0x00,    OLED_CMD);  //���õ�����ʼ��ַ
		my_oled_write_byte(0x10,    OLED_CMD);  //���ø�����ʼ��ַ
        my_iic_start();
        my_iic_write_byte(OLED_WRITE_ADDR);
        my_iic_wait_ack();
        my_iic_write_byte(OLED_DATA_REG);
        my_iic_wait_ack();
        for(n=0;n<128;n++)
        {
            my_iic_write_byte(OLED_GRAM[n][i]); 
            my_iic_wait_ack();
        }
        my_iic_stop();
    }
}

void my_oled_clear(void)
{
	uint8 i,n;
	for(i=0;i<8;i++)
	{
        for(n=0;n<128;n++)
        {
            OLED_GRAM[n][i]=0;  //�����������
        }
    }
	my_oled_refresh();             //������ʾ
}

void my_oled_init(void)
{
    my_oled_write_byte(0xAE,OLED_CMD);//--turn off oled panel
	my_oled_write_byte(0x00,OLED_CMD);//---set low column address
	my_oled_write_byte(0x10,OLED_CMD);//---set high column address
	my_oled_write_byte(0x40,OLED_CMD);//--set start line address  Set Mapping RAM Display Start Line (0x00~0x3F)
	my_oled_write_byte(0x81,OLED_CMD);//--set contrast control register
	my_oled_write_byte(0xCF,OLED_CMD);// Set SEG Output Current Brightness
	my_oled_write_byte(0xA1,OLED_CMD);//--Set SEG/Column Mapping     0xa0���ҷ��� 0xa1����
	my_oled_write_byte(0xC8,OLED_CMD);//Set COM/Row Scan Direction   0xc0���·��� 0xc8����
	my_oled_write_byte(0xA6,OLED_CMD);//--set normal display
	my_oled_write_byte(0xA8,OLED_CMD);//--set multiplex ratio(1 to 64)
	my_oled_write_byte(0x3f,OLED_CMD);//--1/64 duty
	my_oled_write_byte(0xD3,OLED_CMD);//-set display offset	Shift Mapping RAM Counter (0x00~0x3F)
	my_oled_write_byte(0x00,OLED_CMD);//-not offset
	my_oled_write_byte(0xd5,OLED_CMD);//--set display clock divide ratio/oscillator frequency
	my_oled_write_byte(0x80,OLED_CMD);//--set divide ratio, Set Clock as 100 Frames/Sec
	my_oled_write_byte(0xD9,OLED_CMD);//--set pre-charge period
	my_oled_write_byte(0xF1,OLED_CMD);//Set Pre-Charge as 15 Clocks & Discharge as 1 Clock
	my_oled_write_byte(0xDA,OLED_CMD);//--set com pins hardware configuration
	my_oled_write_byte(0x12,OLED_CMD);
	my_oled_write_byte(0xDB,OLED_CMD);//--set vcomh
	my_oled_write_byte(0x30,OLED_CMD);//Set VCOM Deselect Level
	my_oled_write_byte(0x20,OLED_CMD);//-Set Page Addressing Mode (0x00/0x01/0x02)
	my_oled_write_byte(0x02,OLED_CMD);//
	my_oled_write_byte(0x8D,OLED_CMD);//--set Charge Pump enable/disable
	my_oled_write_byte(0x14,OLED_CMD);//--set(0x10) disable
	my_oled_clear();
	my_oled_write_byte(0xAF,OLED_CMD);
    
    my_oled_color_turn(0);              //0������ʾ, 1 ��ɫ��ʾ
    my_oled_display_turn(0);            //0������ʾ, 1 ��Ļ��ת��ʾ
    my_oled_string(7, 5, DEV_NAME, OLED_FONT_0806, OLED_DIS_NORMAL);
    // oled �߿� begin
    my_oled_line(0,     0,  127,    0,  OLED_DIS_NORMAL);   // ---1
    my_oled_line(0,     15, 127,    15, OLED_DIS_NORMAL);   // ---2
    my_oled_line(0,     16, 127,    16, OLED_DIS_NORMAL);   // ---3
    my_oled_line(0,     63, 127,    63, OLED_DIS_NORMAL);   // ---4
    my_oled_line(0,     0,  0,      63, OLED_DIS_NORMAL);   // ��
    my_oled_line(127,   0,  127,    63, OLED_DIS_NORMAL);   // ��
    // end
    my_oled_refresh();
}

void my_oled_display_on(uint8 mode)
{
    if(mode == OLED_ON)
    {
        my_oled_write_byte(0x8D,OLED_CMD);//��ɱ�ʹ��
	    my_oled_write_byte(0x14,OLED_CMD);//������ɱ�
	    my_oled_write_byte(0xAF,OLED_CMD);//������Ļ
    }
    else if(mode == OLED_OFF)
    {
        my_oled_write_byte(0x8D,OLED_CMD);//��ɱ�ʹ��
	    my_oled_write_byte(0x10,OLED_CMD);//�رյ�ɱ�
	    my_oled_write_byte(0xAE,OLED_CMD);//�ر���Ļ
    }
	
}
