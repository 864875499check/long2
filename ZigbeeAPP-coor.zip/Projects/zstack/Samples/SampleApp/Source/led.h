#ifndef __LED_H__
#define __LED_H__

#define LED      P2_2
#define LED_ON  0
#define LED_OFF 1

extern void my_led_init(void);


#endif