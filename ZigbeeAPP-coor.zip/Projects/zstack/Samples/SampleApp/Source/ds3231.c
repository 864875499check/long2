#include "ds3231.h"

DateTime_t my_time;
DateTime_t set_time;

static void my_ds3231_write_byte(uint8 reg, uint8 data)
{
    my_iic_start();
    my_iic_write_byte(DS3231_WRITE_ADDR);   // ds3231 д�豸��ַ
    my_iic_wait_ack();
    my_iic_write_byte(reg);                 // reg ��ַ
    my_iic_wait_ack();
    my_iic_write_byte(data);                // byte ����
    my_iic_wait_ack();
    my_iic_stop();
}

static void my_ds3231_read_byte(uint8 reg, uint8* data)
{
    uint8 temp = 0;
    
    my_iic_start();
    my_iic_write_byte(DS3231_WRITE_ADDR);   // ds3231 д�豸��ַ
    my_iic_wait_ack();
    my_iic_write_byte(reg);                 // reg ��ַ
    my_iic_wait_ack();
    
    my_iic_start();                         // *�ظ���ʼ�ź�*
    my_iic_write_byte(DS3231_READ_ADDR);    // ds3231 ���豸��ַ
    my_iic_wait_ack();
    temp = my_iic_read_byte(0);            // ��ȡ����, NAck
    *data = temp;
    my_iic_stop();
}

uint8 bcdToDec(uint8 byte)
{
	uint8 temp_H , temp_L;
	temp_L = byte & 0x0f;
	temp_H = (byte & 0xf0) >> 4;
	return ( temp_H * 10 )+ temp_L;
}

void my_ds3231_set_date(DateTime_t t)
{
    uint8 year, mon, day;
    uint8 temp_H , temp_L;
    
    year = t.year;
    temp_L = year % 10;
    temp_H = year / 10;
    year = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_YEAR_REG, year);    //set year
    
    mon = t.month;
    temp_L = mon % 10;
	temp_H = mon / 10;
	mon = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_MONTH_REG, mon);   //set mon
    
    day = t.dayofmonth;
    temp_L = day % 10;
	temp_H = day / 10;
	day = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_MDAY_REG, day);    //set day
}

void my_ds3231_set_time(DateTime_t t)
{
    uint8 hour, min, sec;
    uint8 temp_H , temp_L;
    
    hour = t.hour;
    temp_L = hour % 10;
	temp_H = hour / 10;
	hour = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_HOUR_REG, hour);    //set hour
    
    min = t.minute;
    temp_L = min % 10;
	temp_H = min / 10;
	min = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_MIN_REG, min);      //set min
    
    sec = t.second;
    temp_L = sec % 10;
	temp_H = sec / 10;
	sec = (temp_H << 4) + temp_L;
    my_ds3231_write_byte(DS3231_SEC_REG, sec);      //set sec
}

void my_ds3231_get_date(DateTime_t* ans)
{
    uint8 data = 0;
    
    my_ds3231_read_byte(DS3231_YEAR_REG, &data);
    ans->year = bcdToDec(data) + 2000;
    
    my_ds3231_read_byte(DS3231_MONTH_REG, &data);
    ans->month = bcdToDec(data);
    
    my_ds3231_read_byte(DS3231_MDAY_REG, &data);
    ans->dayofmonth = bcdToDec(data);
}

void my_ds3231_get_time(DateTime_t* ans)
{
    uint8 data = 0;
    
    my_ds3231_read_byte(DS3231_HOUR_REG, &data);
    ans->hour = bcdToDec(data);
    
    my_ds3231_read_byte(DS3231_MIN_REG, &data);
    ans->minute = bcdToDec(data);
    
    my_ds3231_read_byte(DS3231_SEC_REG, &data);
    ans->second = bcdToDec(data);
}

void my_ds3231_init(void)
{
    
}