#include "sgp30.h"
#include "my_delay.h"

uint32 SGP30_Data = 0;
uint16 SGP30_CO2 = 0;
uint16 SGP30_TVOC = 0;

void my_sgp30_init(void)
{
    SCL_Out();
    SDA_Out();
    my_iic_write_word(0x20, 0x03, SGP30_WRITE_ADDR);
}

uint32 my_sgp30_read(void)
{
    uint32 data;
    uint8  crc;
    
    my_iic_start();
    my_iic_write_byte(SGP30_READ_ADDR);
    my_iic_wait_ack();
    data = my_iic_read_byte(1);
    data <<= 8;
    data |= my_iic_read_byte(1);
    data <<= 8;
    
    crc = my_iic_read_byte(1);  // crc data
    crc = crc;
    
    data |= my_iic_read_byte(1);
    data <<= 8;
    data |= my_iic_read_byte(0);
    my_iic_stop();
    
    return data;
}

void my_sgp30_test(void)
{
    my_iic_write_word(0x20, 0x08, SGP30_WRITE_ADDR);
    my_delay_ms(50);
    SGP30_Data  = my_sgp30_read();
    SGP30_CO2   = (SGP30_Data & 0xffff0000) >> 16;  // ȡ�� CO2 Ũ��ֵ
    SGP30_TVOC  = (SGP30_Data & 0x0000ffff);        // ȡ�� TVOC ֵ 
}