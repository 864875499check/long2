#ifndef __UART_H__
#define __UART_H__

#include <stdio.h>
#include "main.h"

extern void my_uart1_init(void);
extern void my_uart1_send(const uint8 *data, uint8 len);

#endif