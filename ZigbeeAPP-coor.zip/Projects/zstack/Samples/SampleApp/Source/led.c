#include "led.h"
#include <ioCC2530.h>

void my_led_init(void)
{
  P2DIR |= (0x01<<2);   // p2.2

  LED = LED_ON;
}