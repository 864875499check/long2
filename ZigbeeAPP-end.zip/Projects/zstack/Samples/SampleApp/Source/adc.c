#include "adc.h"

//��ص�ѹ
uint16 my_battery_voltage_d = 0;
float  my_battery_voltage_f = 0.0;
uint8  my_battery_voltage_p = 0;
//MQ2��ѹ
uint16 my_mq2_voltage_d = 0;
uint16 my_mq2 = 0;
//��ǿ��ѹ
uint16 my_light_voltage_d = 0;
uint16 my_light = 0;


void my_adc_init(void)
{
    //HalAdcInit();   // ����ʼ��Ĭ�ϲο���ѹ
    HalAdcSetReference(HAL_ADC_REF_AVDD);   // �޸Ĳο���ѹΪ AVDD
}

void my_get_battery_voltage(uint8 resolution)
{
    switch(resolution)
    {
    case HAL_ADC_RESOLUTION_8:
    case HAL_ADC_RESOLUTION_10:
    case HAL_ADC_RESOLUTION_12:
    case HAL_ADC_RESOLUTION_14:
        my_battery_voltage_d = HalAdcRead(HAL_ADC_CHANNEL_0, HAL_ADC_RESOLUTION_14);
        break;
    }
    
    my_battery_voltage_f = ((float)my_battery_voltage_d/8191) * MY_VDD * ADC_MULTI;
    if(my_battery_voltage_f > MY_BAT_FULL)
        my_battery_voltage_f = MY_BAT_FULL;
    my_battery_voltage_p = 100 - (( MY_BAT_FULL - my_battery_voltage_f ) / ( MY_BAT_FULL - MY_BAT_EMPTY ) * 100);    // �����ٷֱ�
    
    // �͵������
    if (my_battery_voltage_f < MIN_BATTERY_VOLTAGE)
    {
        printf("[Error:check the battery!]\r\n");
        my_battery_voltage_f = 0.0; // no battery connected��
        my_battery_voltage_p = 0;
        
    }
    else if(my_battery_voltage_f < LOW_BATTERY_VOLTAGE)
    {
        printf("[Warning:charge the battery!]\r\n");    // low voltage��
    } 
}

void my_get_mq2(uint8 resolution)
{
    switch(resolution)
    {
    case HAL_ADC_RESOLUTION_8:
    case HAL_ADC_RESOLUTION_10:
    case HAL_ADC_RESOLUTION_12:
    case HAL_ADC_RESOLUTION_14:
        my_mq2_voltage_d = HalAdcRead(HAL_ADC_CHANNEL_5, HAL_ADC_RESOLUTION_14);
        break;
    }
    
    my_mq2 = my_mq2_voltage_d;
}

void my_get_light(uint8 resolution)
{
    switch(resolution)
    {
    case HAL_ADC_RESOLUTION_8:
    case HAL_ADC_RESOLUTION_10:
    case HAL_ADC_RESOLUTION_12:
    case HAL_ADC_RESOLUTION_14:
        // ��ǿ����ѹ
        my_light_voltage_d = HalAdcRead(HAL_ADC_CHANNEL_4, HAL_ADC_RESOLUTION_14);
        break;
    }
    
    if(my_light_voltage_d > MY_LIGHT_MAX)
        my_light_voltage_d = MY_LIGHT_MAX;
    // ��ǿ
    my_light = MY_LIGHT_MAX - my_light_voltage_d;
}