#include "shtc3.h"
#include "my_delay.h"

uint32 SHTC3_Data = 0;
float SHTC3_TMP = 0.0;
float SHTC3_HUM = 0.0;

uint32 my_shtc3_read(void)
{
    uint32 data;
    uint8  none;

    my_iic_start();
    my_iic_write_byte(SHTC3_READ_ADDR);
    my_iic_wait_ack();
    
    data = my_iic_read_byte(1);
    data <<= 8;
    data |= my_iic_read_byte(1);
    data <<= 8;
    
    none = my_iic_read_byte(1);
    
    data |= my_iic_read_byte(1);
    data <<= 8;
    data |= my_iic_read_byte(1);
    
    none = my_iic_read_byte(0);
    my_iic_stop();
    
    return data;
}

void my_shtc3_test(void)
{
    uint16 tmp, hum;
    
    my_iic_write_word(0x2C, 0x06, SHTC3_WRITE_ADDR);
    my_delay_ms(50);
    SHTC3_Data = my_shtc3_read();
    tmp = (SHTC3_Data & 0xffff0000) >> 16;  // ԭʼ 16bit ��ʪ������
    hum = (SHTC3_Data & 0x0000ffff);
    
    SHTC3_TMP = (175.0*(float)tmp/65535.0-45.0);  // �����¶�
    SHTC3_HUM = (100.0*(float)hum/65535.0);       // ����ʪ��
}