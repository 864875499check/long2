#ifndef UART1_H
#define UART1_H
#ifdef __cplusplus
extern "C"
{
#endif
#include "main.h"
#include <string.h>
 
#define UART1_RX_BUFF_MAX    60
#define UART1_TX_BUFF_MAX    60
#define UART1_THRESHOLD      (UART1_RX_BUFF_MAX / 2)
#define UART1_IDLE_TIMEOUT   6
 
extern uint8 UART1_RX_BUFF[UART1_RX_BUFF_MAX];//���ջ����� 
extern uint8 UART1_RX_STA;                    //����״̬���	
extern uint8 UART1_RX_LEN;                    //�������ݳ���
 
extern void my_uart1_hal_init(uint8 baudRate);
extern void my_uart1_data_process(void);
extern void my_uart1_hal_data_receive( uint8 port, uint8 event );
extern void my_uart1_hal_reset( void );
#if !IS_END_DEV
__near_func int putchar(int c);
#endif
 
#ifdef __cplusplus
}
#endif
#endif /* UART1_H */