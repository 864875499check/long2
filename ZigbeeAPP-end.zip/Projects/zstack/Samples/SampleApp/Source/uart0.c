#include "uart0.h"
#include "hal_uart.h"

uint8 UART0_RX_BUFF[UART0_RX_BUFF_MAX];//���ջ�����
uint8 UART0_RX_STA = 0;                //����״̬���
uint8 UART0_RX_LEN = 0;                //�������ݳ���
 
void my_uart0_hal_init(uint8 baudRate)
{
  halUARTCfg_t uartConfig;
 
  uartConfig.configured           = TRUE;
  uartConfig.baudRate             = baudRate;
  uartConfig.flowControl          = FALSE;
  uartConfig.flowControlThreshold = UART0_THRESHOLD;
  uartConfig.rx.maxBufSize        = UART0_RX_BUFF_MAX;
  uartConfig.tx.maxBufSize        = UART0_TX_BUFF_MAX;
  uartConfig.idleTimeout          = UART0_IDLE_TIMEOUT;
  uartConfig.intEnable            = TRUE;
  uartConfig.callBackFunc         = my_uart0_hal_data_receive;   // ���ڽ��ջص�����
 
  HalUARTOpen (HAL_UART_PORT_0, &uartConfig);
} 

// uart0 �������ݺ�������, ����buffer---UART0_RX_BUFF, ���ݳ���---UART0_RX_LEN
void my_uart0_data_process(void)
{
    switch(MY_DEVICE_TYPE)
    {
        case MY_COORDINATOR_TYPE:   // Э����
        case MY_ROUTER_TYPE:        // ·����
        case MY_END_DEVICE_TYPE:    // �ն˽ڵ�
            osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_UART0_MSG_EVT, 0 );
            break;
            
        default:
            printf("Error[my_uart0_data_process - error device type]\r\n");
        break;
    }
}

// uart0 �������ݻص�����, һ��������60�ֽ�����, �������ݽ�����־"\r\n"---0x0A 0x0D
void my_uart0_hal_data_receive( uint8 port, uint8 event )
{
    uint8 Res;
    (void)event;  // Intentionally unreferenced parameter
 
    while (Hal_UART_RxBufLen(port))
    {
        HalUARTRead (port, &Res, 1);//��ȡһ���ֽ�
        UART0_RX_BUFF[UART0_RX_STA&0x3F]=Res;
        UART0_RX_STA++;
 
        if((UART0_RX_STA&0x80)==0)//����δ���
        {
            if(UART0_RX_STA&0x40)//ǰһ�����յ������ݽ������ġ�ǰһ�롱
            {
                if     (Res==0x0A)UART0_RX_STA |= 0x80;//���������
                else if(Res!=0x0D)UART0_RX_STA &= 0xBF;//���ǽ���������ǰ�����������־��0
            }
            else
            {
                if(Res==0x0D)UART0_RX_STA |= 0x40;
            }
        }
 
        if((UART0_RX_STA&0x80)==0x80)   // ���ݽ������
        {
            UART0_RX_LEN = (UART0_RX_STA&0x3F)-2;   // �޳������ݽ�����־"\r\n"---0x0A 0x0D
            // user code begin
            
            my_uart0_data_process();
            
            // user code end
            //my_uart0_hal_reset(); // �������buffer
            break;
        }
    }
}

// uart0���ݽ���buffer��λ/���
void my_uart0_hal_reset(void)
{
    memset(UART0_RX_BUFF, 0, UART0_RX_BUFF_MAX);
    UART0_RX_STA = 0;
}

#if IS_END_DEV
// printf����ض���
__near_func int putchar(int c)
{
    // ����HAL��uart0дһ���ֽ�
    HalUARTWrite(HAL_UART_PORT_0, (uint8*)&c, 1);
}
#endif

#if IS_END_DEV
#include "my_log.h"
uint8 mode = 1;
#endif
void my_uart0_cmd(uint8 *rxdata)
{
#if IS_END_DEV
    // �޸�ʱ��
    if(UART0_RX_BUFF[0] == 0xAB && UART0_RX_BUFF[1] == 0xCD && UART0_RX_BUFF[2] == 0xEF)
    {
        set_time.year         = bcdToDec(UART0_RX_BUFF[3]);
        set_time.month        = bcdToDec(UART0_RX_BUFF[4]);
        set_time.dayofmonth   = bcdToDec(UART0_RX_BUFF[5]);
        set_time.hour         = bcdToDec(UART0_RX_BUFF[6]);
        set_time.minute       = bcdToDec(UART0_RX_BUFF[7]);
        set_time.second       = bcdToDec(UART0_RX_BUFF[8]);
        my_ds3231_set_date(set_time);
        my_ds3231_set_time(set_time);
    }
    if(rxdata[0] == 'c' && rxdata[1] == 'm' && rxdata[2] == 'd')
    {
        /* "cmd" --- 2 byte cmd */
        // OLED
        if(rxdata[3] == 'o' && rxdata[4] == 'l' && rxdata[5] == 'e' && rxdata[6] == 'd')
        {
            // oled---display turn
            mode = mode ? 0 : 1;
            my_oled_display_on(mode);
        }
        // get my_time
        else if(rxdata[3] == 't' && rxdata[4] == 'i' && rxdata[5] == 'm' && rxdata[6] == 'e')
        {
            my_log_time();
        }
        // get all_sensor_data
        else if(rxdata[3] == 's' && rxdata[4] == 's')
        {
            if(rxdata[5] == 'a')        // all
                my_log_all();
            else if(rxdata[5] == 'p')   // power
                my_log_pwr();
            else if(rxdata[5] == 't')   // temperature & humidity
                my_log_shtc3();
            else if(rxdata[5] == 'g')   // gas
            {
                my_log_mq2();
                my_log_sgp30();
            }
            else if(rxdata[5] == 'l')   // light
                my_log_light();
        }
        // I2C
        else if(rxdata[3] == 'i' && rxdata[4] == '2' && rxdata[5] == 'c')
        {
            // i2c---power turn
            if(MY_IIC_DEV_PWR == IIC_PWR_ON)
                my_iic_device_pwr(IIC_PWR_OFF);           
            else
            {
                my_iic_device_pwr(IIC_PWR_ON);
                my_init_all();
            }
        }
        // AF send MSG
        else if(rxdata[3] == 'a' && rxdata[4] == 'f')
        {
            osal_start_timerEx( SampleApp_TaskID, SAMPLEAPP_SEND_DATA_MSG_EVT, 0 );
        }
    }
#endif
}
