#ifndef SGP30_H
#define SGP30_H

#include "my_i2c.h"

extern uint32 SGP30_Data;
extern uint16 SGP30_CO2;
extern uint16 SGP30_TVOC;

#define SGP30_READ_ADDR  ((0x58<<1) + 1)  //SGP30�Ķ���ַ
#define SGP30_WRITE_ADDR ((0x58<<1) + 0)  //SGP30��д��ַ

extern void my_sgp30_init(void);
extern uint32 my_sgp30_read(void);
extern void my_sgp30_test(void);

#endif  // sgp30.h