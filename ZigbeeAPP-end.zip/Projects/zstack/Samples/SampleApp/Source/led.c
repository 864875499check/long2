#include "led.h"
#include <ioCC2530.h>

void my_led_init(void)
{
  P2SEL &= ~0x01;   // P2.0 io??
  P2DIR |= 0x01;    // ??

  LED_P20 = LED_ON;
}