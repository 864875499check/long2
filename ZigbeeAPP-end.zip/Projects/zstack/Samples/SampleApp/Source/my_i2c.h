#ifndef MY_I2C_H
#define MY_I2C_H

#include "main.h"

#define IIC_DELAY_TIME      4       // ����ģ��iicͨ������(�о�����ʱ�䷶Χ)
#define IIC_ERROR_TIMEOUT   300     // �ȴ�Ӧ���źų�ʱʱ��
#define IIC_ACK             0       // SDA 0 --- Ack
#define IIC_NACK            1       // SDA 1 --- NAck

#define IIC_SCL     P1_0
#define IIC_SDA     P1_1
#define SCL_Out()   my_set_p1_mode(IO_0, IO_OUTPUT_MODE)    // P1.0 ���
#define SDA_Out()   my_set_p1_mode(IO_1, IO_OUTPUT_MODE)    // P1.1 ���
#define SDA_In()    my_set_p1_mode(IO_1, IO_INPUT_MODE)     // P1.1 ����


extern void my_iic_sleep(void);

extern void my_iic_start(void);
extern void my_iic_stop(void);
extern void my_iic_ack(void);
extern void my_iic_nack(void);
extern uint8 my_iic_wait_ack(void);

extern void my_iic_write_byte(uint8 data);
extern void my_iic_write_word(uint8 a, uint8 b, uint8 addr);
extern uint8 my_iic_read_byte(uint8 ack);

#endif // my_i2c.h