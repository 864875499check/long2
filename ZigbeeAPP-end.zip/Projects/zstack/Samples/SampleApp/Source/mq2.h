#ifndef MQ2_H
#define MQ2_H

#include "main.h"


extern void my_mq2_init(void);
extern void my_mq2_warning(void);
__interrupt void P0_INT(void);


#endif // mq2.h