#ifndef MY_DELAY_H
#define MY_DELAY_H

#include "main.h"

extern void my_delay_us(uint16 timeout);
extern void my_delay_ms(uint16 timeout);



#endif  // my_delay.h