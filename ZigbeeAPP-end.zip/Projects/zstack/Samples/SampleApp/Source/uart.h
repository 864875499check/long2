#ifndef __UART_H__
#define __UART_H__

#include <stdio.h>

extern void my_uart1_init(void);
extern void UR1SendString(unsigned char *str, unsigned char count);

#endif